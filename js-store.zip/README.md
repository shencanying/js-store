# js-store

##运行

### 1.yarn install(如果不行再运行一下npm install)


### 2.yarn run server
