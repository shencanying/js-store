import './scss/main.scss';
import './scss/commom.scss';
import './scss/library.scss';
let main = require("./js/main");

main.default();